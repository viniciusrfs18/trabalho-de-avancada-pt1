package com.engauto.vinicius;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.AsyncTask;
import android.util.Log;

import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.DirectionsApi;
import com.google.maps.GeoApiContext;
import com.google.maps.model.DirectionsResult;
import com.google.maps.model.DirectionsRoute;
import com.google.maps.model.TravelMode;
public class Route {
    private Context context;
    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
     RouteCallback callback;

    public Route(Context context, GoogleMap map, RouteCallback callback) {
        this.context = context;
        mMap = map;
        this.callback = callback;
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(context);
    }

    @SuppressLint("MissingPermission")
    public void calculateRoute() {
        if (isLocationPermissionGranted())  {
            fusedLocationClient.getLastLocation()
                    .addOnSuccessListener(location -> {
                        if (location != null) {
                            LatLng currentLocation = new LatLng(location.getLatitude(), location.getLongitude());
                            LatLng destination = new LatLng(-19.8157, -43.9542);

                            GeoApiContext geoContext = new GeoApiContext.Builder()
                                    .apiKey("AIzaSyCupl562mJ85xpiMsqbTiivjKmE-c8Bo7w")
                                    .build();

                            DirectionsApiRequestTask requestTask = new DirectionsApiRequestTask(geoContext, currentLocation, destination);
                            requestTask.execute();
                        } else {
                            Log.e("Route", "Falha");
                            callback.onRouteError();
                        }
                    })
                    .addOnFailureListener(e -> {
                        Log.e("Route", "Falha pra ultima loc", e);
                        callback.onRouteError();
                    });
        } else {
            Log.e("Route", "Localização nao permitida");
            callback.onRouteError();
        }
    }

    private void drawRoute(DirectionsRoute route) {
        mMap.clear();

        mMap.addMarker(new MarkerOptions().position(new LatLng(route.legs[0].startLocation.lat, route.legs[0].startLocation.lng)).title("Origem"));
        mMap.addMarker(new MarkerOptions().position(new LatLng(route.legs[0].endLocation.lat, route.legs[0].endLocation.lng)).title("Destino"));

        // Desenhe a rota no mapa

        PolylineOptions polylineOptions = new PolylineOptions();
        for (LatLng point : route.overviewPolyline.decodePath()) {
            polylineOptions.add(point);
        }
        mMap.addPolyline(polylineOptions);


        LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();
        boundsBuilder.include(new LatLng(route.legs[0].startLocation.lat, route.legs[0].startLocation.lng));
        boundsBuilder.include(new LatLng(route.legs[0].endLocation.lat, route.legs[0].endLocation.lng));
        LatLngBounds bounds = boundsBuilder.build();
        mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 100));

        // Retorne a rota calculada para a classe Main
        callback.onRouteCalculated(route);
    }

    public long calculateTime(Location startLocation, Location endLocation, double speed) {
        float[] distanceResults = new float[1];
        Location.distanceBetween(startLocation.getLatitude(), startLocation.getLongitude(),
                endLocation.getLatitude(), endLocation.getLongitude(), distanceResults);

        float distance = distanceResults[0];
        double timeInSeconds = distance / speed;

        return (long) (timeInSeconds * 1000);
    }
    private double calculateDistance(LatLng startLocation, LatLng endLocation) {
        double startLatitude = startLocation.latitude;
        double startLongitude = startLocation.longitude;
        double endLatitude = endLocation.latitude;
        double endLongitude = endLocation.longitude;

        int earthRadius = 6371; // Raio da Terra em quilômetros

        // Conversão de graus para radianos
        double dLat = Math.toRadians(endLatitude - startLatitude);
        double dLon = Math.toRadians(endLongitude - startLongitude);

        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(startLatitude)) * Math.cos(Math.toRadians(endLatitude)) *
                        Math.sin(dLon / 2) * Math.sin(dLon / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        // Distância em quilômetros
        double distance = earthRadius * c;
        return distance;
    }

    public interface RouteCallback {
        void onRouteCalculated(DirectionsRoute route);
        void onRouteError();
    }

    private boolean isLocationPermissionGranted() {
        int permission = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION);
        return permission == PackageManager.PERMISSION_GRANTED;
    }
    private class DirectionsApiRequestTask extends AsyncTask<Void, Void, DirectionsResult> {
        private GeoApiContext geoContext;
        private LatLng origin;
        private LatLng destination;

        public DirectionsApiRequestTask(GeoApiContext geoContext, LatLng origin, LatLng destination) {
            this.geoContext = geoContext;
            this.origin = origin;
            this.destination = destination;
        }

        @Override
        protected DirectionsResult doInBackground(Void... voids) {
            try {
                return DirectionsApi.newRequest(geoContext)
                        .mode(TravelMode.DRIVING)
                        .origin(new com.google.maps.model.LatLng(origin.latitude, origin.longitude))
                        .destination(new com.google.maps.model.LatLng(destination.latitude, destination.longitude))
                        .await();
            } catch (Exception e) {
                Log.e("Route", "falha ", e);
                return null;
            }
        }

        @Override
        protected void onPostExecute(DirectionsResult directionsResult) {
            if (directionsResult != null && directionsResult.routes != null && directionsResult.routes.length > 0) {
                DirectionsRoute route = directionsResult.routes[0];
                drawRoute(route);
            } else {
                Log.e("Route", "falha");
                callback.onRouteError();
            }
        }
    }
}
