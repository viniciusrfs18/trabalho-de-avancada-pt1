package com.engauto.vinicius;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationAvailability;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    private static final int REQUEST_LOCATION_PERMISSION = 1;

    private TextView txtRoute;
    private TextView txtSpeed;
    private TextView txtTime;
    private TextView txtDistance;


    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;
    private LocationRequest locationRequest;
    private LocationTracker locationTracker;
    private Constants constants;
    private FetchAddressIntentService addressResultReceiver;

    private Route route;

    private FetchAddressIntentService fetchAddressIntentService;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtRoute = findViewById(R.id.txt_route);
        txtSpeed = findViewById(R.id.txt_speed);
        txtTime = findViewById(R.id.txt_time);
        txtDistance = findViewById(R.id.txt_distance);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        addressResultReceiver = new AddressResultReceiver(new Handler());

        locationTracker = new LocationTracker();
        locationCallback = new LocationCallbackHandler();

        locationRequest = new LocationRequest();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (checkLocationPermission()) {
            startLocationUpdates();
        } else {
            requestLocationPermission();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        stopLocationUpdates();
    }

    private boolean checkLocationPermission() {
        return ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        ActivityCompat.requestPermissions(
                this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_PERMISSION);
    }

    private void startLocationUpdates() {
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
    }

    private void stopLocationUpdates() {
        fusedLocationClient.removeLocationUpdates(locationCallback);
    }

    public void onCalculateRouteClick(View view) {
        double waypointLatitude = -19.8457; // Latitude do ponto de destino
        double waypointLongitude = -43.9542; // Longitude do ponto de destino
        LatLng waypoint = new LatLng(waypointLatitude, waypointLongitude);
        Location currentLocation = locationTracker.getCurrentLocation();
        if (currentLocation != null) {
            LatLng origin = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
            route = new Route(origin, waypoint);
            route.calculateRoute(new Route.RouteCallback() {
                @Override
                public void onRouteReady(String route) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            txtRoute.setText(route);
                        }
                    });
                }
            });
        } else {
            Toast.makeText(this, "Unable to get current location.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);
    }

    private void updateMapLocation(Location location) {
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        mMap.clear();
        mMap.addMarker(new MarkerOptions().position(latLng).title("loc"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
    }

    public double consumodecombustivel(double velocity) {
        // Distância percorrida em km
        double distance = 100; // Exemplo: 100 km

        // Fatores de consumo de gasolina para diferentes velocidades (em litros por km)
        double consumo80 = 0.08;
        double consumo100 = 0.1;
        double consumo120 = 0.12;

        double consumption;

        if (velocity <= 80) {
            consumption = consumo80;
        } else if (velocity <= 100) {
            consumption = consumo100;
        } else {
            consumption = consumo120;
        }

        // Consumo de gasolina em litros
        double fuelConsumption = consumption * distance;

        return fuelConsumption;

        double consumo = consumodecombustivel(100);

        System.out.println("Consumo a 80 km/h: " + consumo + " litros");


        private void updateAddressTextViews (Address address){
            if (address != null) {
                String locality = address.getLocality();
                String adminArea = address.getAdminArea();
                String countryName = address.getCountryName();
                String addressLine = address.getAddressLine(0);


                TextView txtRoute = findViewById(R.id.txtRoute);
                txtRoute.setText("Route: " + route.getSummary());

            }
        }

        private void displayLocationAvailability ( boolean isLocationAvailable){
            // Aaaaaaaaaaa interface do usuário para mostrar  da localização

        }

        Location location;
        private class LocationCallbackHandler extends LocationCallback {
            //
            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                location = locationResult.getLastLocation();
                updateMapLocation(location);
                updateAddress(location);
                updateSpeed(location);
                updateDistance(location);
                updateTime(location);
            }

            @Override
            public void onLocationAvailability(LocationAvailability locationAvailability) {
                super.onLocationAvailability(locationAvailability);
                displayLocationAvailability(locationAvailability.isLocationAvailable());
            }
        }

        private void updateAddress (Location location){
            if (Geocoder.isPresent() && location != null) {
                Intent intent = new Intent(this, FetchAddressIntentService.class);
                intent.putExtra(FetchAddressIntentService.Constants.RECEIVER, addressResultReceiver);
                intent.putExtra(FetchAddressIntentService.Constants.LOCATION_DATA_EXTRA, location);
                startService(intent);
            }
        }
//plotar na tela
        private void updateSpeed (Location location){
            if (location != null) {
                float velocidade = location.getSpeed();
                txtSpeed.setText(String.format(Locale.getDefault(), "%.2f m/s", velocidade));
            }
        }

        private void updateDistance (Location location){
            if (location != null && route != null) {
                double distancia = route.calculateDistance(location);
                txtDistance.setText(String.format(Locale.getDefault(), "%.2f km", distancia));
            }
        }

        private void updateTime (Location location){
            if (location != null && route != null) {
                long tempo = route.calculateTime(location);
                txtTime.setText(String.format(Locale.getDefault(), "%02d:%02d:%02d",
                        (tempo / (1000 * 60 * 60)) % 24,
                        (tempo / (1000 * 60)) % 60,
                        (tempo / 1000) % 60));
            }
        }

        private class AddressResultReceiver extends ResultReceiver {

            public AddressResultReceiver(Handler handler) {
                super(handler);
            }

            @Override
            protected void onReceiveResult(int resultCode, Bundle resultData) {
                if (resultCode == FetchAddressIntentService.Constants.SUCCESS_RESULT) {
                    Address address = resultData.getParcelable(FetchAddressIntentService.Constants.RESULT_ADDRESS);
                    updateAddressTextViews(address);
                } else {
                    Toast.makeText(MainActivity.this, "incapaz de buscar o endereço", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
