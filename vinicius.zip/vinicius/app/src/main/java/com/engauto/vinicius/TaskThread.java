package com.engauto.vinicius;

public class TaskThread extends Thread {
    private Route route;
    private LocationTracker locationTracker;

    public TaskThread(Route route, LocationTracker locationTracker) {
        this.route = route;
        this.locationTracker = locationTracker;
    }

    @Override
    public void run() {
        // Executar as tarefas em paralelo
        route.calculateRoute1();
        locationTracker.startLocationUpdates();

        // Aguardar um tempo (por exemplo, 10 segundos)
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Parar as atualizações de localização e obter a localização atual
        locationTracker.stopLocationUpdates();
        Location location = locationTracker.getCurrentLocation();

        // Obter as informações de latitude e longitude da rota
        double waypointLatitude = route.getWaypointLatitude();
        double waypointLongitude = route.getWaypointLongitude();

        // Calcular a distância entre a localização atual e o waypoint da rota
        float distance = calculateDistance(location.getLatitude(), location.getLongitude(), waypointLatitude, waypointLongitude);

        // Calcular o tempo de viagem e a velocidade de locomoção
        float travelTime = distance / location.getSpeed();
        float speed = location.getSpeed();

        // Exibir os resultados
        Log.d(TAG, "Distance: " + distance);
        Log.d(TAG, "Travel Time: " + travelTime);
        Log.d(TAG, "Speed: " + speed);
    }

    private float calculateDistance(double startLatitude, double startLongitude, double endLatitude, double endLongitude) {
        // Implemente o cálculo da distância entre dois pontos geográficos
        // Aqui está apenas um exemplo simplificado utilizando a fórmula de Haversine:
        double earthRadius = 6371; // raio médio da Terra em quilômetros
        double latDiff = Math.toRadians(endLatitude - startLatitude);
        double lonDiff = Math.toRadians(endLongitude - startLongitude);
        double a = Math.sin(latDiff / 2) * Math.sin(latDiff / 2)
                + Math.cos(Math.toRadians(startLatitude)) * Math.cos(Math.toRadians(endLatitude))
                * Math.sin(lonDiff / 2) * Math.sin(lonDiff / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distance = earthRadius * c;
        return (float) distance;
    }
}
